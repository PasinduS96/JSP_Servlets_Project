-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: computer_shop
-- ------------------------------------------------------
-- Server version	5.7.21-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `idAdmin` varchar(12) NOT NULL,
  `firstName` varchar(45) NOT NULL,
  `lastName` varchar(45) DEFAULT NULL,
  `password` varchar(45) NOT NULL,
  PRIMARY KEY (`idAdmin`),
  UNIQUE KEY `password_UNIQUE` (`password`),
  UNIQUE KEY `idAdmin_UNIQUE` (`idAdmin`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES ('test123','test','test','test');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer` (
  `idcustomer` varchar(45) NOT NULL,
  `firstName` varchar(45) NOT NULL,
  `lastName` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `phoneNumber` varchar(45) NOT NULL,
  PRIMARY KEY (`idcustomer`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES ('2131fesf','aa','aaa','aaa','aaa111'),('ewe','aa','aaa','aaa','1212111');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `distributor`
--

DROP TABLE IF EXISTS `distributor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `distributor` (
  `iddistributor` varchar(12) NOT NULL,
  `companyName` varchar(45) NOT NULL,
  `agentName` varchar(45) NOT NULL,
  `comPhoneNumber` varchar(45) NOT NULL,
  `agtPhoneNumber` varchar(45) NOT NULL,
  `email` varchar(45) DEFAULT NULL,
  `address` varchar(45) NOT NULL,
  PRIMARY KEY (`iddistributor`),
  UNIQUE KEY `iddistributor_UNIQUE` (`iddistributor`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `distributor`
--

LOCK TABLES `distributor` WRITE;
/*!40000 ALTER TABLE `distributor` DISABLE KEYS */;
INSERT INTO `distributor` VALUES ('111','test','test','324','123','a@a.com','123/1,a,a'),('test','testCom','testAgt1','1234890','1234567','test@test.com','12/A,test,test');
/*!40000 ALTER TABLE `distributor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `items` (
  `iditems` varchar(10) NOT NULL,
  `itemName` varchar(45) NOT NULL,
  `price` float NOT NULL,
  `availableUnits` int(11) DEFAULT NULL,
  `distributorID` varchar(45) DEFAULT NULL,
  `discountPercentage` float DEFAULT NULL,
  PRIMARY KEY (`iditems`),
  UNIQUE KEY `iditems_UNIQUE` (`iditems`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `items`
--

LOCK TABLES `items` WRITE;
/*!40000 ALTER TABLE `items` DISABLE KEYS */;
INSERT INTO `items` VALUES ('test','test',1200,1,'1234',30);
/*!40000 ALTER TABLE `items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `idorders` varchar(12) NOT NULL,
  `itemID` varchar(45) DEFAULT NULL,
  `disID` varchar(45) DEFAULT NULL,
  `units` varchar(45) DEFAULT NULL,
  `date` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idorders`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES ('3232','dssd','dsds','sdsds','2323232'),('323423434','fddf','fgfdg','fdfd','34232434234'),('345','gfg','fgg','gfgf','gfgfgf'),('a1','effsd','fdsfdssfd','fdsdfs','fdsfsdfsd'),('aaaaaaaa','111','1111','1111111aaaa','aaaaaaa'),('bvc','bv','bvc','vb','vbc'),('csdcsafd','dsdsdsdssd','dssdsd','dsdsd','dsdssd'),('cxxcx','xcxc','cxxc','xcxc','cxcx'),('fdgfd','fgdfg','fgdfdg','fdgfd','fdgfd'),('fdsf','fsdds','dsfffsd','ffsdfsd','fsdsdffsd'),('fdsfdf','dsfsfds','fdfdfds','dffddfs','ddffdfd'),('fghgh','fhggfh','hghgf','fhtghfg','fhgfhg'),('ghnh','hjghjg','hjghgj','hjghjg','jhghjggjh'),('hjg','hgfj','hjg','hjg','fhyg'),('sdsad','sdadsa','sadsad','dssdsda','sadsdsda'),('sdsadsdsd','dsfsfs','sfdsfsd','fsdfsdf','fdsfdfds'),('test','test','test','11','123456'),('test123','121','321','11','1212112'),('vcxvcx','vcxvccvx','vcvcx','cvcxxcvcx','vcxccxxc');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales`
--

DROP TABLE IF EXISTS `sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales` (
  `idinvoice` varchar(20) NOT NULL,
  `productName` varchar(45) NOT NULL,
  `date` varchar(10) NOT NULL,
  `numOfItems` int(11) NOT NULL,
  `price` double NOT NULL,
  `total` double NOT NULL,
  PRIMARY KEY (`idinvoice`),
  UNIQUE KEY `idinvoice_UNIQUE` (`idinvoice`),
  UNIQUE KEY `date_UNIQUE` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales`
--

LOCK TABLES `sales` WRITE;
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
INSERT INTO `sales` VALUES ('1000','Q','1',3,5,15),('11','asd','2018-10-10',12,1,12),('111','111','111',1,2,2),('12','gfx','212',4,5,20),('122','222','21233',222,1,222),('122567','wr','2018-05-13',100,10,1000),('134','333','21212',2000,3,6000),('222','222','222',222,1,222),('555','sfd','555',5,2,10),('bbbbbb','bbbbb','2222',2222,1111,2468642),('q212','212','21211',11111,2,22222),('TEST','AAA','123',12,4,48),('tst','tst','2323',33,1,33),('www','11','1111',11111,2,22222);
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staff`
--

DROP TABLE IF EXISTS `staff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staff` (
  `idstaff` varchar(12) NOT NULL,
  `firstName` varchar(45) NOT NULL,
  `lastName` varchar(45) DEFAULT NULL,
  `reputation` varchar(45) NOT NULL,
  `phoneNumber` varchar(20) NOT NULL,
  `email` varchar(60) DEFAULT NULL,
  `address` varchar(45) DEFAULT NULL,
  `password` varchar(45) NOT NULL,
  PRIMARY KEY (`idstaff`),
  UNIQUE KEY `idstaff_UNIQUE` (`idstaff`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff`
--

LOCK TABLES `staff` WRITE;
/*!40000 ALTER TABLE `staff` DISABLE KEYS */;
INSERT INTO `staff` VALUES ('234test','test',NULL,'1234567890','tets','tets/test','tst@test.com','test'),('456test','sas','ass','sas','null','sxas','saas','asas'),('dsxfsd','sdsfd',NULL,'sdfsdf','sdsdf','sdffsd','sdfdss@m.com','sdfsfd'),('null','null','null','null','null','null','null','null'),('sdfds','sdfsf',NULL,'dsfs','dsdfs','sdsdf','dsffds@dsd.com','fsdsfd'),('xgfd','fdgdf','fdgdfg','fdgg','fdgfdg','gfdgd@s.com','fdgdgf','fdfdg');
/*!40000 ALTER TABLE `staff` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-05-19 20:54:45
