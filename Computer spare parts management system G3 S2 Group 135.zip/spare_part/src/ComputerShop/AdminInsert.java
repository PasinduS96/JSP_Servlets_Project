package ComputerShop;

import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class AdminInsert extends HttpServlet{
	
	private static final long serialVersionUID = 1L;

public void init(ServletConfig config) throws ServletException{
  super.init(config);
  }
 
  public void doPost(HttpServletRequest req, 
  HttpServletResponse res) throws ServletException,
  IOException{

 try {
	  String a = req.getParameter("idAdmin");
	  String b = req.getParameter("firstName");
	  String c = req.getParameter("lastName");
	  String d = req.getParameter("password");
		
	  	AdminDB dbinsert = new AdminDB();
	  	
		Connection connection =dbinsert.getCon();
		Statement stmt = connection.createStatement();
		
		stmt.executeUpdate("insert into admin(idAdmin,firstName,lastName,password) VALUES ('"+a+"', '"+b+"', '"+c+"', '"+d+"', ) ");
		res.sendRedirect("AdminMan.jsp");
  // show that the new account has been created
  
  }
  catch(SQLException e){
  e.printStackTrace();
  }
  catch (Exception ex){
  ex.printStackTrace();
  }
  finally {

 
  }
}
}